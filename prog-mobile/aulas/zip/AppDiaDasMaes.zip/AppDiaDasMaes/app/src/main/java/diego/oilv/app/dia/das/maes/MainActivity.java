package diego.oilv.app.dia.das.maes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void telaMensagem(View view){
        Intent intent = new Intent(this, Mensagem.class);
        startActivity(intent);
    }

    public void telaOrigem(View view){
        Intent intent = new Intent(this, Origem.class);
        startActivity(intent);
    }

    public void telaPresente(View view){
        Intent intent = new Intent(this, Presente.class);
        startActivity(intent);
    }

    public void telaQuiz(View view){
        Intent intent = new Intent(this, Quiz.class);
        startActivity(intent);
    }
}