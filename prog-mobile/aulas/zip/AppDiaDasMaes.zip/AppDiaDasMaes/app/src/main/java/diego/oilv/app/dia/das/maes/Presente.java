package diego.oilv.app.dia.das.maes;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.TreeMap;

public class Presente extends AppCompatActivity {

        public static String obterSugestaoPresente(double valor) {
            TreeMap<Integer, List<String>> presentes = new TreeMap<>();

            presentes.put(20, Arrays.asList(
                    "Buquê de flores do campo",
                    "Caixa de bombons finos",
                    "Porta-retrato com foto da família",
                    "Ecobag personalizada"
            ));

            presentes.put(50, Arrays.asList(
                    "Vela aromática premium",
                    "Caneca com infusor de chá",
                    "Kit de sabonetes artesanais",
                    "Planta ornamental (Orquídea ou Suculenta)"
            ));

            presentes.put(100, Arrays.asList(
                    "Livro Best-seller + Marcador especial",
                    "Kit de Skincare (Máscaras e Sérum)",
                    "Almofada de leitura ergonômica",
                    "Conjunto de xícaras de porcelana"
            ));

            presentes.put(200, Arrays.asList(
                    "Perfume nacional premium",
                    "Roupão de banho felpudo",
                    "Dia de manicure e pedicure VIP",
                    "Cesta de café da manhã completa"
            ));

            presentes.put(400, Arrays.asList(
                    "Kindle (Leitor de e-books)",
                    "Fritadeira Air Fryer 4L",
                    "Massageador de pescoço elétrico",
                    "Smart Speaker (Alexa) de última geração"
            ));

            presentes.put(700, Arrays.asList(
                    "Cafeteira de cápsulas moderna",
                    "Smartwatch focado em saúde",
                    "Jantar em restaurante de alta gastronomia",
                    "Aparelho de limpeza facial ultrassônico"
            ));

            presentes.put(1500, Arrays.asList(
                    "Smartphone com boa câmera",
                    "Tablet para leitura e lazer",
                    "Robô aspirador inteligente",
                    "Final de semana em hotel fazenda local"
            ));

            presentes.put(3000, Arrays.asList(
                    "Notebook para uso pessoal",
                    "Smart TV 4K 50\"",
                    "Anel de ouro com pedra semipreciosa",
                    "Viagem aérea nacional com acompanhante"
            ));

            presentes.put(6000, Arrays.asList(
                    "iPhone de geração atual",
                    "Retiro em SPA de luxo (All inclusive)",
                    "Reforma de cantinho de leitura/descanso",
                    "Intercâmbio cultural de curta duração"
            ));

            presentes.put(12000, Arrays.asList(
                    "Cruzeiro pela costa brasileira",
                    "Joia de grife exclusiva",
                    "Projeto de decoração de sala completo",
                    "Pacote de viagem para a Europa"
            ));

            Integer valorMaisProximo = presentes.floorKey((int) valor);

            if (valorMaisProximo == null) {
                valorMaisProximo = presentes.firstKey();
            }

            List<String> sugestoes = presentes.get(valorMaisProximo);
            Random random = new Random();

            return sugestoes.get(random.nextInt(sugestoes.size()));
        }

    EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_presente);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        input = findViewById(R.id.editTextText);
    }

    public void butao(View view){

        if(input.getText().toString().isEmpty()){

            Toast.makeText(
                    this,
                    "Informe um valor!",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        double valor =
                Double.parseDouble(
                        input.getText().toString()
                );

        String presente =
                obterSugestaoPresente(valor);

        new AlertDialog.Builder(this)
                .setTitle("💖 Presente Ideal")
                .setMessage(
                        "Sugestão para sua mãe:\n\n" +
                                presente
                )
                .setPositiveButton("Perfeito!", null)
                .show();
        input.setText("");
    }
}

