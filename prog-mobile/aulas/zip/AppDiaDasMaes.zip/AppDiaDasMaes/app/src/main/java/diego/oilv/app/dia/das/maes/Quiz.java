package diego.oilv.app.dia.das.maes;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class Quiz extends AppCompatActivity {
    static int perguntas = 0;
    static String[] perguntasMae = {

            "Sua mãe gosta de flores?",
            "Sua mãe prefere chocolate ao invés de salgados?",
            "Sua mãe gosta de assistir filmes?",
            "Sua mãe gosta de cozinhar?",
            "Sua mãe gosta de presentes feitos à mão?",
            "Sua mãe gosta de perfumes?",
            "Sua mãe gosta de livros?",
            "Sua mãe gosta de viajar?",
            "Sua mãe gosta de música?",
            "Sua mãe gosta de tirar fotos?",
            "Sua mãe gosta de café?",
            "Sua mãe gosta de maquiagem?",
            "Sua mãe gosta de assistir séries?",
            "Sua mãe gosta de decoração?",
            "Sua mãe gosta de tecnologia?",
            "Sua mãe gosta de ganhar cartas?",
            "Sua mãe gosta de sair para jantar?",
            "Sua mãe gosta de plantas?",
            "Sua mãe gosta de animais?",
            "Sua mãe gosta de presentes simples?",
            "Sua mãe gosta de roupas?",
            "Sua mãe gosta de joias?",
            "Sua mãe gosta de usar relógios?",
            "Sua mãe gosta de spa ou massagem?",
            "Sua mãe gosta de cozinhas modernas?",
            "Sua mãe gosta de artesanato?",
            "Sua mãe gosta de praia?",
            "Sua mãe gosta de frio?",
            "Sua mãe gosta de perfumes doces?",
            "Sua mãe gosta de perfumes suaves?",
            "Sua mãe gosta de velas aromáticas?",
            "Sua mãe gosta de chá?",
            "Sua mãe gosta de surpresas?",
            "Sua mãe gosta de passeios em família?",
            "Sua mãe gosta de doces?",
            "Sua mãe gosta de pizza?",
            "Sua mãe gosta de redes sociais?",
            "Sua mãe gosta de assistir novelas?",
            "Sua mãe gosta de roupas confortáveis?",
            "Sua mãe gosta de sapatos?",
            "Sua mãe gosta de bolsas?",
            "Sua mãe gosta de brincos?",
            "Sua mãe gosta de colares?",
            "Sua mãe gosta de cozinhar sobremesas?",
            "Sua mãe gosta de ganhar flores naturais?",
            "Sua mãe gosta de fotografar?",
            "Sua mãe gosta de pintar ou desenhar?",
            "Sua mãe gosta de jogos?",
            "Sua mãe gosta de descansar nos finais de semana?",
            "Sua mãe gosta de natureza?",
            "Sua mãe gosta de acampar?",
            "Sua mãe gosta de luxo?",
            "Sua mãe gosta de ambientes organizados?",
            "Sua mãe gosta de assistir vídeos no YouTube?",
            "Sua mãe gosta de moda?",
            "Sua mãe gosta de presentes emocionantes?",
            "Sua mãe gosta de tecnologia moderna?",
            "Sua mãe gosta de cozinhar para a família?",
            "Sua mãe gosta de momentos tranquilos?",
            "Sua mãe gosta de ouvir rádio ou podcasts?",
            "Sua mãe gosta de animais de estimação?",
            "Sua mãe gosta de presentes personalizados?",
            "Sua mãe gosta de experimentar comidas novas?",
            "Sua mãe gosta de selfies?",
            "Sua mãe gosta de cantar?",
            "Sua mãe gosta de dançar?",
            "Sua mãe gosta de quadros decorativos?",
            "Sua mãe gosta de ambientes minimalistas?",
            "Sua mãe gosta de presentes úteis?",
            "Sua mãe gosta de colecionar objetos?",
            "Sua mãe gosta de ganhar surpresas românticas da família?",
            "Sua mãe gosta de um café da manhã especial?",
            "Sua mãe gosta de maratonar séries?",
            "Sua mãe gosta de dormir cedo?",
            "Sua mãe gosta de roupas elegantes?",
            "Sua mãe gosta de itens dourados?",
            "Sua mãe gosta de decoração floral?",
            "Sua mãe gosta de ouvir músicas calmas?",
            "Sua mãe gosta de viagens em família?",
            "Sua mãe gosta de ganhar abraços apertados?"
    };

    public static String obterPerguntaAleatoria() {

        Random random = new Random();

        int indice =
                random.nextInt(perguntasMae.length);

        return perguntasMae[indice];
    }

    TextView pergunta;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quiz);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        pergunta = findViewById(R.id.quiz);
        pergunta.setText(obterPerguntaAleatoria());
    }

    public void butao(View view){
        perguntas++;
        pergunta.setText(obterPerguntaAleatoria());
        if(perguntas > 10){
            new AlertDialog.Builder(this)
                    .setTitle("💖 Resultado")
                    .setMessage(
                            "Sua mãe é incrível."
                    )
                    .setPositiveButton("Verdade!", null)
                    .show();
            perguntas = 0;
        }

    }
}