package ifrs.festa.junina;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private int palhacos;
    private int cachorros;
    private int brigadeiros;
    //
    private TextView textViewPalhacos;
    private TextView textViewCachorros;
    private TextView textViewBrigadeiros;
    private TextView textViewTotal;
    //
    private double valorPalhaco;
    private double valorCachorro;
    private double valorBrigadeiro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        palhacos = 0;
        cachorros = 0;
        brigadeiros = 0;
        //
        textViewPalhacos = findViewById(R.id.palhacos);
        textViewCachorros = findViewById(R.id.cachorros);
        textViewBrigadeiros = findViewById(R.id.brigadeiros);
        textViewTotal = findViewById(R.id.total);
        //
        valorPalhaco = 10.50;
        valorCachorro = 7.50;
        valorBrigadeiro = 3.50;
    }

    public void somarPalhaco(View view){
        palhacos++;
        textViewPalhacos.setText(palhacos + "");
        mensagem();
    }
    public void subtrairPalhaco(View view){
        if(palhacos < 1){
            return;
        }
        palhacos--;
        textViewPalhacos.setText(palhacos + "");
        mensagem();
    }
    //
    public void somarCachorro(View view){
        cachorros++;
        textViewCachorros.setText(cachorros + "");
        mensagem();
    }
    public void subtrairCachorro(View view){
        if(cachorros < 1){
            return;
        }
        cachorros--;
        textViewCachorros.setText(cachorros + "");
        mensagem();
    }
    //
    public void somarBrigadeiro(View view){
        brigadeiros++;
        textViewBrigadeiros.setText(brigadeiros + "");
        mensagem();
    }
    public void subtrairBrigadeiro(View view){
        if(brigadeiros < 1){
            return;
        }
        brigadeiros--;
        textViewBrigadeiros.setText(brigadeiros + "");
        mensagem();
    }

    public void mensagem(){
        double valor = (cachorros * valorCachorro) + (palhacos * valorPalhaco) + (brigadeiros * valorBrigadeiro);
        String mensagem = String.format("Total: R$ %.2f", valor).replace(".", ",");
        textViewTotal.setText(mensagem);
    }
}