package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Bebida extends AppCompatActivity {

    EditText marca;
    EditText quantidade;
    EditText preco;
    EditText tipo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bebida);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        this.marca = findViewById(R.id.marca);
        this.quantidade = findViewById(R.id.quantidade);
        this.preco = findViewById(R.id.preco);
        this.tipo = findViewById(R.id.tipo);
    }

    public void salvar(View view){
        String texto  = "BEBIDA\n\nMarca: " + marca.getText().toString() + "\nQuantidade: " + quantidade.getText().toString() + " ml\nPreço: R$ " + preco.getText().toString() + "\nTipo: " + tipo.getText().toString();
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("infos", texto);
        startActivity(intent);
        finish();
    }
}