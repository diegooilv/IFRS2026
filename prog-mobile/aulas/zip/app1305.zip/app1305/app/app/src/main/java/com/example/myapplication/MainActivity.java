package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    String infos  = "";
    TextView info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        infos = getIntent().getStringExtra("infos");
        infos = infos != null ? infos : "";
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        info = findViewById(R.id.infos);
        info.setText(this.infos);
    }

    public void telaBebida(View view){
        Intent intent = new Intent(this, Bebida.class);
        startActivity(intent);
    }

    public void telaComida(View view){
        Intent intent = new Intent(this, Comida.class);
        startActivity(intent);
    }
}